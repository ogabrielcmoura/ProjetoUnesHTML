# Dracula for [BetterDiscord](https://betterdiscord.net)

> A dark theme for [BetterDiscord](https://betterdiscord.net).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/betterdiscord](https://draculatheme.com/betterdiscord).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/betterdiscord/graphs/contributors).

[![Kabir Kwatra](https://avatars0.githubusercontent.com/u/30360059?v=3&s=70)](https://github.com/KabirKwatra) | [![Zeno Rocha](https://avatars2.githubusercontent.com/u/398893?v=3&s=70)](https://github.com/zenorocha)
--- | ---
[Kabir Kwatra](https://github.com/KabirKwatra) | [Zeno Rocha](https://github.com/zenorocha)

## License

[MIT License](./LICENSE)
